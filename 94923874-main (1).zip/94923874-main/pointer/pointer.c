#include <stdio.h>
#include <cs50.h>
#include <string.h>

int main(void)
{
    /*
    int n = 50;
    int *p = &n;
    printf("%p\n", p);
    */

    int array1[] = {1,3,5,7,9,11,13,15,17,19};
    string s1 = "Hello World!";
    int length = strlen(s1);

    //printf("%c\n", *s1);
    //printf("%c\n", *(s1+1));
    //printf("%i\n", *(array1+2));

    for(int i = 0; i < length; i++)
    {
        printf("%c\n", *(s1+i));
        
    }

    printf("ENDS Here\n");
    return 0;
}