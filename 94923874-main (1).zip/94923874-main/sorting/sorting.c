#include <stdio.h>

// Selection sort AND Bubble sort

void selection_sort(int array[]);
void bubble_sort(int array[]);

int a = 0;
int counter = 0;

int main (void){

    //int array[10] = {1,3,5,7,9,2,4,6,8,10};
    int array[10] = {10,8,5,6,1,4,3,2,7,9};
    //int array[10] = {1,2,3,4,5,6,7,8,9,10};
    //int array[10] = {10,9,8,7,6,5,4,3,2,1};


    printf("To Sort :");

    for (int i=0; i<10; i++){
        printf("%i-->",array[i]);
    }
    printf("\n");

    //selection_sort(array);
    bubble_sort(array);

    return 0;
}

void selection_sort(int array[])
{
    printf("selection sort\n");
    //liner sort ?
    for (int i=0; i<10; i++){
        for (int j=1; i+j<10; j++){
                //printf("i=%i & j=%i\n",i,j);
                if (array[i] > array[i+j]){
                    //printf("front=%i & back =%i\n",array[i],array[i+j]);
                    a = array[i]-array[i+j];
                    array[i+j]=array[i];
                    array[i]=array[i]-a;
                    //printf("swap front=%i & back =%i\n",array[i],array[i+j]);
                    counter ++;

                    for (int k=0; k<10; k++){
                        printf("-->%i",array[k]);
                    }
                    printf("\n");

            }
        }
    }
    printf("counter=%i\n",counter);
}

void bubble_sort(int array[])
{
    printf("bubble sort\n");
    for (int i = 0; i < 10; i++)
    {
       for (int j = 0; j < 9 - i; j++)
       {
            //printf("1st = %i\n", j);
            if (array[j] > array[j+1])
            {
                //printf("front=%i & back =%i\n",array[j],array[j+1]);
                a = array[j]-array[j+1];
                array[j+1]=array[j];
                array[j]=array[j]-a;
                //printf("swap front=%i & back =%i\n",array[j],array[j+1]);
                counter ++;

                for (int k=0; k<10; k++)
                {
                    printf("-->%i",array[k]);
                }
                printf("\n");
            }
       }
   }
   printf("counter=%i\n",counter);
}