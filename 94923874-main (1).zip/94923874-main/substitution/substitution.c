#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>


bool isletter(char c);
bool check_input(int argc, string argv[]);

int main(int argc, string argv[])
{

    string plaintext;
    string ciphertext = "";
    int cipher_ASCII[26][2] = { {65, 0}, {66, 0}, {67, 0}, {68, 0}, {69, 0}, {70, 0}, {71, 0}, {72, 0}, {73, 0}, {74, 0}, {75, 0}, {76, 0}, {77, 0}, {78, 0}, {79, 0}, {80, 0}, {81, 0}, {82, 0}, {83, 0}, {84, 0}, {85, 0}, {86, 0}, {87, 0}, {88, 0}, {89, 0}, {90, 0} };
    int j = 0;
    int k = 0;
    //int d = 0; // ASCII difference between "A" and "a"

    if (!check_input(argc, argv))
    {
        for (int i = 0; i <= 25; i++)
        {
            if (isupper(argv[1][i]))
            {
                cipher_ASCII[i][1] = argv[1][i] - 65 - i ; // ASCII of "A"
                printf("ASCII %i --> factor = %i\n", cipher_ASCII[i][0], cipher_ASCII[i][1]);
            }
            else
            {
                cipher_ASCII[i][1] = argv[1][i] - 65 - i - 32; // ASCII of "A"
                printf("ASCII %i --> factor = %i\n", cipher_ASCII[i][0], cipher_ASCII[i][1]);
            }
        }

        plaintext = get_string("plaintext: ");
        while (plaintext[j] != '\0')
        {
            //printf("progress....%i\n", j);
            if (isupper(plaintext[j]))
            {
                k = 0;
                while (plaintext[j] != cipher_ASCII[k][0] + 0)
                {
                    k++;
                }
                plaintext[j] = plaintext[j] + cipher_ASCII[k][1];
                //printf("plaintext --> = %c\n", plaintext[j]);
                j++;
            }
            else if (islower(plaintext[j]))
            {
                k = 0;
                while (plaintext[j] != cipher_ASCII[k][0] + 32) // ASCII difference between "A" and "a"
                {
                    k++;
                }
                plaintext[j] = plaintext[j] + cipher_ASCII[k][1];
                //printf("plaintext --> = %c\n", plaintext[j]);
                j++;
            }
            else
            {
                j++;
            }
        }
    }
    else
    {
        return 1;
    }
    //printf("ciphertext: %s",plaintext); // Don't know why this won't work.
    printf("ciphertext: ");
    int length = strlen(plaintext);
    for (int a = 0; a < length ; a++)
    {
        printf("%c", plaintext[a]);
    }
    printf("\n");
}

// Functions below

bool check_input(int argc, string argv[])
{
    int key_length ;
    int i = 0;

    if (argc == 2)
    {
        key_length = strlen(argv[1]);

        if (key_length != 26) // Catch shorter than 26 Char
        {
            printf("Key must contain 26 characters.\n");
            return 1;
        }

        while (argv[1][i] != '\0') // Catch non-alphabatic
        {
            //printf("char = %c\n", argv[1][i]);
            if (!isletter(argv[1][i]))
            {
                printf("Usage: ./substitution key\n");
                return 1;
            }
            else
            {
                i++;
            }
        }

        for (int j = 0 ; j <= 25; j++)  // Catch duplication
        {
            for (int k = 0 ; k <= 25; k++)
            {
                if ((argv[1][j] == argv[1][k]) && (j - k != 0))
                {
                    printf("Duplicated key (%c)\n", argv[1][j]);
                    return 1;
                }
            }
        }
    }
    else
    {
        printf("Usage: ./substitution key\n");
        return 1;
    }
    return 0;
}

bool isletter(char c)
{
    if (isupper(c) || islower(c))
    {
        return true;
    }
    else
    {
        return false;
    }
}