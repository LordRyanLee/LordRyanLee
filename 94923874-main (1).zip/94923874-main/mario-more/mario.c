#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int height;
    int counter = 0;

    do
    {
        height = get_int("Height: ");
    }
    while (height < 1 || height > 8);

    do
    {
        for (int x = 1; x < height; x++)
        {
            printf(" ");
        }
        for (int x = 0; x <= counter; x++)
        {
            printf("#");
        }
        printf("  "); // adding middle space column
        for (int x = 0; x <= counter; x++)
        {
            printf("#");
        }
        printf("\n");
        height--;
        counter++;
    }
    while (height > 0);
}
