#include <ctype.h>
#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

int count_letters(string text);
int count_words(string text);
int count_sentences(string text);

int main(void)
{

    string TEXT;

    float letters;
    float words;
    float sentences;
    float index;
    int grade;

    TEXT = get_string("Text: ");

    letters = count_letters(TEXT);
    words = count_words(TEXT);
    sentences = count_sentences(TEXT);

    index = (0.0588 * (letters / words * 100)) - (0.296 * (sentences / words * 100)) - 15.8 ;
    grade = round(index);

    if (grade >= 16)
    {
        printf("Grade 16+\n");
    }
    else if (grade < 1)
    {
        printf("Before Grade 1\n");
    }
    else
    {
        printf("Grade %i\n", grade);
    }

}

int count_letters(string text)
{
    int letters = 0;
    int i = 0;
    do
    {
        if (isupper(text[i]) || islower(text[i]))
        {
            letters += 1;
        }
        i++;
    }
    while (text[i] != '\0');
    return letters;
}

int count_words(string text)
{
    int words = 1; // One space means two words
    int i = 0;
    do
    {
        if (text[i] == 32) // ASCII 32 = space
        {
            words += 1;
        }
        i++;
    }
    while (text[i] != '\0');
    return words;
}

int count_sentences(string text)
{
    int sentences = 0;
    int i = 1; // If the first char is (./!/?) it's not a sentense
    do
    {
        if ((text[i] == 46) || (text[i] == 33) || (text[i] == 63)) // ASCII 46,33,63 = ./!/?
        {
            sentences += 1;
        }
        i++;
    }
    while (text[i] != '\0');
    return sentences;
}
