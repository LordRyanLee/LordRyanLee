#include <ctype.h>
#include <cs50.h>
#include <stdio.h>
#include <string.h>

// Points assigned to each letter of the alphabet
int POINTS[] = {1, 3, 3, 2, 1, 4, 2, 4, 1, 8, 5, 1, 3, 1, 1, 3, 10, 1, 1, 1, 1, 4, 4, 8, 4, 10};

int compute_score(string word);

int main(void)
{
    // Get input words from both players
    string word1 = get_string("Player 1: ");
    string word2 = get_string("Player 2: ");

    // Score both words
    int score1 = compute_score(word1);
    int score2 = compute_score(word2);

    // TODO: Print the winner
    //printf("score1 = %i",score1);
    //printf("score2 = %i",score2);

    if (score1 > score2)
    {
        printf("\nPlayer 1 wins!");
    }
    else if (score1 < score2)
    {
        printf("\nPlayer 2 wins!");
    }
    else
    {
        printf("Tie!");
    }
}

int compute_score(string word)
{
    // TODO: Compute and return score for string
    int score = 0;
    int i = 0;
    int key;

    do
    {
        if isupper(word[i])
        {
            key = word[i] - 65;
        }
        else if islower(word[i])
        {
            key = word[i] - 97;
        }
        else
        {
            i++;
            break;
        }
        //printf("key = %i\n",word[i]);
        score += POINTS[key];
        //printf("points = %i\n",POINTS[key]);
        //printf("score = %i\n",score);
        i++;
    }
    while (word[i] != '\0');

    return score;
}