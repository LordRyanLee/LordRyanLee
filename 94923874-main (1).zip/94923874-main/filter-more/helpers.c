#include "helpers.h"
#include "stdio.h"
#include "math.h"


int limit (int input);

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            float avg;
            avg = (image[i][j].rgbtBlue + image[i][j].rgbtRed + image[i][j].rgbtGreen) / 3.0;
            image[i][j].rgbtBlue = round(avg);
            image[i][j].rgbtRed = round(avg);
            image[i][j].rgbtGreen = round(avg);
        }
    }
    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < (int)floor(width / 2.0) ; j++)
        {
            int tempB, tempR, tempG;
            tempB = image[i][j].rgbtBlue;
            tempR = image[i][j].rgbtRed;
            tempG = image[i][j].rgbtGreen;

            image[i][j].rgbtBlue = image[i][width - j - 1].rgbtBlue;
            image[i][j].rgbtRed = image[i][width - j - 1].rgbtRed;
            image[i][j].rgbtGreen = image[i][width - j - 1].rgbtGreen;

            image[i][width - j - 1].rgbtBlue = tempB;
            image[i][width - j - 1].rgbtRed = tempR;
            image[i][width - j - 1].rgbtGreen = tempG;
        }
    }
    return;
}


// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{

    RGBTRIPLE image2[height][width];
    int tempB, tempR, tempG;

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width ; j++)
        {
            image2[i][j] = image[i][j];
        }
    }

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width ; j++)
        {
            if ((i == 0) && (j == 0)) // top-left
            {
                tempB = round(((image2[i][j].rgbtBlue + image2[i][j+1].rgbtBlue) + (image2[i+1][j].rgbtBlue + image2[i+1][j+1].rgbtBlue)) / 4.0);
                tempR = round(((image2[i][j].rgbtRed + image2[i][j+1].rgbtRed) + (image2[i+1][j].rgbtRed + image2[i+1][j+1].rgbtRed)) / 4.0);
                tempG = round(((image2[i][j].rgbtGreen + image2[i][j+1].rgbtGreen) + (image2[i+1][j].rgbtGreen + image2[i+1][j+1].rgbtGreen)) / 4.0);
            }
            else if ((i == 0) && (j == width-1)) // top-right
            {
                tempB = round(((image2[i][j-1].rgbtBlue + image2[i][j].rgbtBlue) + (image2[i+1][j-1].rgbtBlue + image2[i+1][j].rgbtBlue)) / 4.0);
                tempR = round(((image2[i][j-1].rgbtRed + image2[i][j].rgbtRed) + (image2[i+1][j-1].rgbtRed + image2[i+1][j].rgbtRed)) / 4.0);
                tempG = round(((image2[i][j-1].rgbtGreen + image2[i][j].rgbtGreen) + (image2[i+1][j-1].rgbtGreen + image2[i+1][j].rgbtGreen)) / 4.0);
            }
            else if ((i == height-1) && (j == 0)) // bottom-left
            {
                tempB = round(((image2[i-1][j].rgbtBlue + image2[i-1][j+1].rgbtBlue) + (image2[i][j].rgbtBlue + image2[i][j+1].rgbtBlue)) / 4.0);
                tempR = round(((image2[i-1][j].rgbtRed + image2[i-1][j+1].rgbtRed) + (image2[i][j].rgbtRed + image2[i][j+1].rgbtRed)) / 4.0);
                tempG = round(((image2[i-1][j].rgbtGreen + image2[i-1][j+1].rgbtGreen) + (image2[i][j].rgbtGreen + image2[i][j+1].rgbtGreen)) / 4.0);
            }
            else if ((i == height-1) && (j == width-1)) // bottom-right
            {
                tempB = round(((image2[i-1][j-1].rgbtBlue + image2[i-1][j].rgbtBlue) + (image2[i][j-1].rgbtBlue + image2[i][j].rgbtBlue)) / 4.0);
                tempR = round(((image2[i-1][j-1].rgbtRed + image2[i-1][j].rgbtRed) + (image2[i][j-1].rgbtRed + image2[i][j].rgbtRed)) / 4.0);
                tempG = round(((image2[i-1][j-1].rgbtGreen + image2[i-1][j].rgbtGreen) + (image2[i][j-1].rgbtGreen + image2[i][j].rgbtGreen)) / 4.0);
            }
            else if (i == 0) // top edge
            {
                tempB = round(((image2[i][j-1].rgbtBlue + image2[i][j].rgbtBlue + image2[i][j+1].rgbtBlue) + (image2[i+1][j-1].rgbtBlue + image2[i+1][j].rgbtBlue + image2[i+1][j+1].rgbtBlue)) / 6.0);
                tempR = round(((image2[i][j-1].rgbtRed + image2[i][j].rgbtRed + image2[i][j+1].rgbtRed) + (image2[i+1][j-1].rgbtRed + image2[i+1][j].rgbtRed + image2[i+1][j+1].rgbtRed)) / 6.0);
                tempG = round(((image2[i][j-1].rgbtGreen + image2[i][j].rgbtGreen + image2[i][j+1].rgbtGreen) + (image2[i+1][j-1].rgbtGreen + image2[i+1][j].rgbtGreen + image2[i+1][j+1].rgbtGreen)) / 6.0);
            }
            else if (i == height-1) // bottom edge
            {
                tempB = round(((image2[i-1][j-1].rgbtBlue + image2[i-1][j].rgbtBlue + image2[i-1][j+1].rgbtBlue) + (image2[i][j-1].rgbtBlue + image2[i][j].rgbtBlue + image2[i][j+1].rgbtBlue)) / 6.0);
                tempR = round(((image2[i-1][j-1].rgbtRed + image2[i-1][j].rgbtRed + image2[i-1][j+1].rgbtRed) + (image2[i][j-1].rgbtRed + image2[i][j].rgbtRed + image2[i][j+1].rgbtRed)) / 6.0);
                tempG = round(((image2[i-1][j-1].rgbtGreen + image2[i-1][j].rgbtGreen + image2[i-1][j+1].rgbtGreen) + (image2[i][j-1].rgbtGreen + image2[i][j].rgbtGreen + image2[i][j+1].rgbtGreen)) / 6.0);
            }
            else if (j == 0) // left edge
            {
                tempB = round(((image2[i-1][j].rgbtBlue + image2[i-1][j+1].rgbtBlue) + (image2[i][j].rgbtBlue + image2[i][j+1].rgbtBlue) + (image2[i+1][j].rgbtBlue + image2[i+1][j+1].rgbtBlue)) / 6.0);
                tempR = round(((image2[i-1][j].rgbtRed + image2[i-1][j+1].rgbtRed) + (image2[i][j].rgbtRed + image2[i][j+1].rgbtRed) + (image2[i+1][j].rgbtRed + image2[i+1][j+1].rgbtRed)) / 6.0);
                tempG = round(((image2[i-1][j].rgbtGreen + image2[i-1][j+1].rgbtGreen) + (image2[i][j].rgbtGreen + image2[i][j+1].rgbtGreen) + (image2[i+1][j].rgbtGreen + image2[i+1][j+1].rgbtGreen)) / 6.0);
            }
            else if (j == width-1) // right edge
            {
                tempB = round(((image2[i-1][j-1].rgbtBlue + image2[i-1][j].rgbtBlue) + (image2[i][j-1].rgbtBlue + image2[i][j].rgbtBlue) + (image2[i+1][j-1].rgbtBlue + image2[i+1][j].rgbtBlue)) / 6.0);
                tempR = round(((image2[i-1][j-1].rgbtRed + image2[i-1][j].rgbtRed) + (image2[i][j-1].rgbtRed + image2[i][j].rgbtRed) + (image2[i+1][j-1].rgbtRed + image2[i+1][j].rgbtRed)) / 6.0);
                tempG = round(((image2[i-1][j-1].rgbtGreen + image2[i-1][j].rgbtGreen) + (image2[i][j-1].rgbtGreen + image2[i][j].rgbtGreen) + (image2[i+1][j-1].rgbtGreen + image2[i+1][j].rgbtGreen)) / 6.0);
            }
            else // all middle pixels
            {
                tempB = round(((image2[i-1][j-1].rgbtBlue + image2[i-1][j].rgbtBlue + image2[i-1][j+1].rgbtBlue) + (image2[i][j-1].rgbtBlue + image2[i][j].rgbtBlue + image2[i][j+1].rgbtBlue) + (image2[i+1][j-1].rgbtBlue + image2[i+1][j].rgbtBlue + image2[i+1][j+1].rgbtBlue)) / 9.0);
                tempR = round(((image2[i-1][j-1].rgbtRed + image2[i-1][j].rgbtRed + image2[i-1][j+1].rgbtRed) + (image2[i][j-1].rgbtRed + image2[i][j].rgbtRed + image2[i][j+1].rgbtRed) + (image2[i+1][j-1].rgbtRed + image2[i+1][j].rgbtRed + image2[i+1][j+1].rgbtRed)) / 9.0);
                tempG = round(((image2[i-1][j-1].rgbtGreen + image2[i-1][j].rgbtGreen + image2[i-1][j+1].rgbtGreen) + (image2[i][j-1].rgbtGreen + image2[i][j].rgbtGreen + image2[i][j+1].rgbtGreen) + (image2[i+1][j-1].rgbtGreen + image2[i+1][j].rgbtGreen + image2[i+1][j+1].rgbtGreen)) / 9.0);
            }
            image[i][j].rgbtBlue = tempB;
            image[i][j].rgbtRed = tempR;
            image[i][j].rgbtGreen = tempG;
        }
    }
    return;
}

// Detect edges
void edges(int height, int width, RGBTRIPLE image[height][width])
{
    int tempBx, tempRx, tempGx;
    int tempBy, tempRy, tempGy;
    float tempBxy, tempRxy, tempGxy;
    RGBTRIPLE image2[height][width];

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width ; j++)
        {
            image2[i][j] = image[i][j];
        }
    }

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width ; j++)
        {
            if ((i == 0) && (j == 0)) // top-left
            {
                tempBx = ((0 * -1 + 0 * 0 + 0 * 1) + (0 * -2 + image2[i][j].rgbtBlue * 0 + image2[i][j+1].rgbtBlue * 2) + (0 * -1 + image2[i+1][j].rgbtBlue * 0 + image2[i+1][j+1].rgbtBlue * 1));
                tempRx = ((0 * -1 + 0 * 0 + 0 * 1) + (0 * -2 + image2[i][j].rgbtRed * 0 + image2[i][j+1].rgbtRed * 2) + (0 * -1 + image2[i+1][j].rgbtRed * 0 + image2[i+1][j+1].rgbtRed * 1));
                tempGx = ((0 * -1 + 0 * 0 + 0 * 1) + (0 * -2 + image2[i][j].rgbtGreen * 0 + image2[i][j+1].rgbtGreen * 2) + (0 * -1 + image2[i+1][j].rgbtGreen * 0 + image2[i+1][j+1].rgbtGreen * 1));

                tempBy = ((0 * -1 + 0 * -2 + 0 * -1) + (0 * 0 + image2[i][j].rgbtBlue * 0 + image2[i][j+1].rgbtBlue * 0) + (0 * 1 + image2[i+1][j].rgbtBlue * 2 + image2[i+1][j+1].rgbtBlue * 1));
                tempRy = ((0 * -1 + 0 * -2 + 0 * -1) + (0 * 0 + image2[i][j].rgbtRed * 0 + image2[i][j+1].rgbtRed * 0) + (0 * 1 + image2[i+1][j].rgbtRed * 2 + image2[i+1][j+1].rgbtRed * 1));
                tempGy = ((0 * -1 + 0 * -2 + 0 * -1) + (0 * 0 + image2[i][j].rgbtGreen * 0 + image2[i][j+1].rgbtGreen * 0) + (0 * 1 + image2[i+1][j].rgbtGreen * 2 + image2[i+1][j+1].rgbtGreen * 1));
            }
            else if ((i == 0) && (j == width - 1)) // top-right
            {
                tempBx = ((0 * -1 + 0 * 0 + 0 * 1) + (image2[i][j-1].rgbtBlue * -2 + image2[i][j].rgbtBlue * 0 + 0 * 2) + (image2[i+1][j-1].rgbtBlue * -1 + image2[i+1][j].rgbtBlue * 0 + 0 * 1));
                tempRx = ((0 * -1 + 0 * 0 + 0 * 1) + (image2[i][j-1].rgbtRed * -2 + image2[i][j].rgbtRed * 0 + 0 * 2) + (image2[i+1][j-1].rgbtRed * -1 + image2[i+1][j].rgbtRed * 0 + 0 * 1));
                tempGx = ((0 * -1 + 0 * 0 + 0 * 1) + (image2[i][j-1].rgbtGreen * -2 + image2[i][j].rgbtGreen * 0 + 0 * 2) + (image2[i+1][j-1].rgbtGreen * -1 + image2[i+1][j].rgbtGreen * 0 + 0 * 1));

                tempBy = ((0 * -1 + 0 * -2 + 0 * -1) + (image2[i][j-1].rgbtBlue * 0 + image2[i][j].rgbtBlue * 0 + 0 * 0) + (image2[i+1][j-1].rgbtBlue * 1 + image2[i+1][j].rgbtBlue * 2 + 0 * 1));
                tempRy = ((0 * -1 + 0 * -2 + 0 * -1) + (image2[i][j-1].rgbtRed * 0 + image2[i][j].rgbtRed * 0 + 0 * 0) + (image2[i+1][j-1].rgbtRed * 1 + image2[i+1][j].rgbtRed * 2 + 0 * 1));
                tempGy = ((0 * -1 + 0 * -2 + 0 * -1) + (image2[i][j-1].rgbtGreen * 0 + image2[i][j].rgbtGreen * 0 + 0 * 0) + (image2[i+1][j-1].rgbtGreen * 1 + image2[i+1][j].rgbtGreen * 2 + 0 * 1));

            }
            else if ((i == height - 1) && (j == 0)) // bottom-left
            {
                tempBx = ((0 * -1 + image2[i-1][j].rgbtBlue * 0 + image2[i-1][j+1].rgbtBlue * 1) + (0 * -2 + image2[i][j].rgbtBlue * 0 + image2[i][j+1].rgbtBlue * 2) + (0 * -1 + 0 * 0 + 0 * 1));
                tempRx = ((0 * -1 + image2[i-1][j].rgbtRed * 0 + image2[i-1][j+1].rgbtRed * 1) + (0 * -2 + image2[i][j].rgbtRed * 0 + image2[i][j+1].rgbtRed * 2) + (0 * -1 + 0 * 0 + 0 * 1));
                tempGx = ((0 * -1 + image2[i-1][j].rgbtGreen * 0 + image2[i-1][j+1].rgbtGreen * 1) + (0 * -2 + image2[i][j].rgbtGreen * 0 + image2[i][j+1].rgbtGreen * 2) + (0 * -1 + 0 * 0 + 0 * 1));

                tempBy = ((0 * -1 + image2[i-1][j].rgbtBlue * -2 + image2[i-1][j+1].rgbtBlue * -1) + (0 * 0 + image2[i][j].rgbtBlue * 0 + image2[i][j+1].rgbtBlue * 0) + (0 * 1 + 0 * 2 + 0 * 1));
                tempRy = ((0 * -1 + image2[i-1][j].rgbtRed * -2 + image2[i-1][j+1].rgbtRed * -1) + (0 * 0 + image2[i][j].rgbtRed * 0 + image2[i][j+1].rgbtRed * 0) + (0 * 1 + 0 * 2 + 0 * 1));
                tempGy = ((0 * -1 + image2[i-1][j].rgbtGreen * -2 + image2[i-1][j+1].rgbtGreen * -1) + (0 * 0 + image2[i][j].rgbtGreen * 0 + image2[i][j+1].rgbtGreen * 0) + (0 * 1 + 0 * 2 + 0 * 1));
            }
            else if ((i == height - 1) && (j == width - 1)) // bottom-right
            {
                tempBx = ((image2[i-1][j-1].rgbtBlue * -1 + image2[i-1][j].rgbtBlue * 0 + 0 * 1) + (image2[i][j-1].rgbtBlue * -2 + image2[i][j].rgbtBlue * 0 + 0 * 2) + (0 * -1 + 0 * 0 + 0 * 1));
                tempRx = ((image2[i-1][j-1].rgbtRed * -1 + image2[i-1][j].rgbtRed * 0 + 0 * 1) + (image2[i][j-1].rgbtRed * -2 + image2[i][j].rgbtRed * 0 + 0 * 2) + (0 * -1 + 0 * 0 + 0 * 1));
                tempGx = ((image2[i-1][j-1].rgbtGreen * -1 + image2[i-1][j].rgbtGreen * 0 + 0 * 1) + (image2[i][j-1].rgbtGreen * -2 + image2[i][j].rgbtGreen * 0 + 0 * 2) + (0 * -1 + 0 * 0 + 0 * 1));

                tempBy = ((image2[i-1][j-1].rgbtBlue * -1 + image2[i-1][j].rgbtBlue * -2 + 0 * -1) + (image2[i][j-1].rgbtBlue * 0 + image2[i][j].rgbtBlue * 0 + 0 * 0) + (0 * 1 + 0 * 2 + 0 * 1));
                tempRy = ((image2[i-1][j-1].rgbtRed * -1 + image2[i-1][j].rgbtRed * -2 + 0 * -1) + (image2[i][j-1].rgbtRed * 0 + image2[i][j].rgbtRed * 0 + 0 * 0) + (0 * 1 + 0 * 2 + 0 * 1));
                tempGy = ((image2[i-1][j-1].rgbtGreen * -1 + image2[i-1][j].rgbtGreen * -2 + 0 * -1) + (image2[i][j-1].rgbtGreen * 0 + image2[i][j].rgbtGreen * 0 + 0 * 0) + (0 * 1 + 0 * 2 + 0 * 1));
            }
            else if (i == 0) // top edge
            {
                tempBx = ((0 * -1 + 0 * 0 + 0 * 1) + (image2[i][j-1].rgbtBlue * -2 + image2[i][j].rgbtBlue * 0 + image2[i][j+1].rgbtBlue * 2) + (image2[i+1][j-1].rgbtBlue * -1 + image2[i+1][j].rgbtBlue * 0 + image2[i+1][j+1].rgbtBlue * 1));
                tempRx = ((0 * -1 + 0 * 0 + 0 * 1) + (image2[i][j-1].rgbtRed * -2 + image2[i][j].rgbtRed * 0 + image2[i][j+1].rgbtRed * 2) + (image2[i+1][j-1].rgbtRed * -1 + image2[i+1][j].rgbtRed * 0 + image2[i+1][j+1].rgbtRed * 1));
                tempGx = ((0 * -1 + 0 * 0 + 0 * 1) + (image2[i][j-1].rgbtGreen * -2 + image2[i][j].rgbtGreen * 0 + image2[i][j+1].rgbtGreen * 2) + (image2[i+1][j-1].rgbtGreen * -1 + image2[i+1][j].rgbtGreen * 0 + image2[i+1][j+1].rgbtGreen * 1));

                tempBy = ((0 * -1 + 0 * -2 + 0 * -1) + (image2[i][j-1].rgbtBlue * 0 + image2[i][j].rgbtBlue * 0 + image2[i][j+1].rgbtBlue * 0) + (image2[i+1][j-1].rgbtBlue * 1 + image2[i+1][j].rgbtBlue * 2 + image2[i+1][j+1].rgbtBlue * 1));
                tempRy = ((0 * -1 + 0 * -2 + 0 * -1) + (image2[i][j-1].rgbtRed * 0 + image2[i][j].rgbtRed * 0 + image2[i][j+1].rgbtRed * 0) + (image2[i+1][j-1].rgbtRed * 1 + image2[i+1][j].rgbtRed * 2 + image2[i+1][j+1].rgbtRed * 1));
                tempGy = ((0 * -1 + 0 * -2 + 0 * -1) + (image2[i][j-1].rgbtGreen * 0 + image2[i][j].rgbtGreen * 0 + image2[i][j+1].rgbtGreen * 0) + (image2[i+1][j-1].rgbtGreen * 1 + image2[i+1][j].rgbtGreen * 2 + image2[i+1][j+1].rgbtGreen * 1));
            }
            else if (i == height - 1) // bottom edge
            {
                tempBx = ((image2[i-1][j-1].rgbtBlue * -1 + image2[i-1][j].rgbtBlue * 0 + image2[i-1][j+1].rgbtBlue * 1) + (image2[i][j-1].rgbtBlue * -2 + image2[i][j].rgbtBlue * 0 + image2[i][j+1].rgbtBlue * 2) + (0 * -1 + 0 * 0 + 0 * 1));
                tempRx = ((image2[i-1][j-1].rgbtRed * -1 + image2[i-1][j].rgbtRed * 0 + image2[i-1][j+1].rgbtRed * 1) + (image2[i][j-1].rgbtRed * -2 + image2[i][j].rgbtRed * 0 + image2[i][j+1].rgbtRed * 2) + (0 * -1 + 0 * 0 + 0 * 1));
                tempGx = ((image2[i-1][j-1].rgbtGreen * -1 + image2[i-1][j].rgbtGreen * 0 + image2[i-1][j+1].rgbtGreen * 1) + (image2[i][j-1].rgbtGreen * -2 + image2[i][j].rgbtGreen * 0 + image2[i][j+1].rgbtGreen * 2) + (0 * -1 + 0 * 0 + 0 * 1));

                tempBy = ((image2[i-1][j-1].rgbtBlue * -1 + image2[i-1][j].rgbtBlue * -2 + image2[i-1][j+1].rgbtBlue * -1) + (image2[i][j-1].rgbtBlue * 0 + image2[i][j].rgbtBlue * 0 + image2[i][j+1].rgbtBlue * 0) + (0 * 1 + 0 * 2 + 0 * 1));
                tempRy = ((image2[i-1][j-1].rgbtRed * -1 + image2[i-1][j].rgbtRed * -2 + image2[i-1][j+1].rgbtRed * -1) + (image2[i][j-1].rgbtRed * 0 + image2[i][j].rgbtRed * 0 + image2[i][j+1].rgbtRed * 0) + (0 * 1 + 0 * 2 + 0 * 1));
                tempGy = ((image2[i-1][j-1].rgbtGreen * -1 + image2[i-1][j].rgbtGreen * -2 + image2[i-1][j+1].rgbtGreen * -1) + (image2[i][j-1].rgbtGreen * 0 + image2[i][j].rgbtGreen * 0 + image2[i][j+1].rgbtGreen * 0) + (0 * 1 + 0 * 2 + 0 * 1));
            }
            else if (j == 0) // left edge
            {
                tempBx = ((0 * -1 + image2[i-1][j].rgbtBlue * 0 + image2[i-1][j+1].rgbtBlue * 1) + (0 * -2 + image2[i][j].rgbtBlue * 0 + image2[i][j+1].rgbtBlue * 2) + (0 * -1 + image2[i+1][j].rgbtBlue * 0 + image2[i+1][j+1].rgbtBlue * 1));
                tempRx = ((0 * -1 + image2[i-1][j].rgbtRed * 0 + image2[i-1][j+1].rgbtRed * 1) + (0 * -2 + image2[i][j].rgbtRed * 0 + image2[i][j+1].rgbtRed * 2) + (0 * -1 + image2[i+1][j].rgbtRed * 0 + image2[i+1][j+1].rgbtRed * 1));
                tempGx = ((0 * -1 + image2[i-1][j].rgbtGreen * 0 + image2[i-1][j+1].rgbtGreen * 1) + (0 * -2 + image2[i][j].rgbtGreen * 0 + image2[i][j+1].rgbtGreen * 2) + (0 * -1 + image2[i+1][j].rgbtGreen * 0 + image2[i+1][j+1].rgbtGreen * 1));

                tempBy = ((0 * -1 + image2[i-1][j].rgbtBlue * -2 + image2[i-1][j+1].rgbtBlue * -1) + (0 * 0 + image2[i][j].rgbtBlue * 0 + image2[i][j+1].rgbtBlue * 0) + (0 * 1 + image2[i+1][j].rgbtBlue * 2 + image2[i+1][j+1].rgbtBlue * 1));
                tempRy = ((0 * -1 + image2[i-1][j].rgbtRed * -2 + image2[i-1][j+1].rgbtRed * -1) + (0 * 0 + image2[i][j].rgbtRed * 0 + image2[i][j+1].rgbtRed * 0) + (0 * 1 + image2[i+1][j].rgbtRed * 2 + image2[i+1][j+1].rgbtRed * 1));
                tempGy = ((0 * -1 + image2[i-1][j].rgbtGreen * -2 + image2[i-1][j+1].rgbtGreen * -1) + (0 * 0 + image2[i][j].rgbtGreen * 0 + image2[i][j+1].rgbtGreen * 0) + (0 * 1 + image2[i+1][j].rgbtGreen * 2 + image2[i+1][j+1].rgbtGreen * 1));
            }
            else if (j == width - 1) // right edge
            {
                tempBx = ((image2[i-1][j-1].rgbtBlue * -1 + image2[i-1][j].rgbtBlue * 0 + 0 * 1) + (image2[i][j-1].rgbtBlue * -2 + image2[i][j].rgbtBlue * 0 + 0 * 2) + (image2[i+1][j-1].rgbtBlue * -1 + image2[i+1][j].rgbtBlue * 0 + 0 * 1));
                tempRx = ((image2[i-1][j-1].rgbtRed * -1 + image2[i-1][j].rgbtRed * 0 + 0 * 1) + (image2[i][j-1].rgbtRed * -2 + image2[i][j].rgbtRed * 0 + 0 * 2) + (image2[i+1][j-1].rgbtRed * -1 + image2[i+1][j].rgbtRed * 0 + 0 * 1));
                tempGx = ((image2[i-1][j-1].rgbtGreen * -1 + image2[i-1][j].rgbtGreen * 0 + 0 * 1) + (image2[i][j-1].rgbtGreen * -2 + image2[i][j].rgbtGreen * 0 + 0 * 2) + (image2[i+1][j-1].rgbtGreen * -1 + image2[i+1][j].rgbtGreen * 0 + 0 * 1));

                tempBy = ((image2[i-1][j-1].rgbtBlue * -1 + image2[i-1][j].rgbtBlue * -2 + 0 * -1) + (image2[i][j-1].rgbtBlue * 0 + image2[i][j].rgbtBlue * 0 + 0 * 0) + (image2[i+1][j-1].rgbtBlue * 1 + image2[i+1][j].rgbtBlue * 2 + 0 * 1));
                tempRy = ((image2[i-1][j-1].rgbtRed * -1 + image2[i-1][j].rgbtRed * -2 + 0 * -1) + (image2[i][j-1].rgbtRed * 0 + image2[i][j].rgbtRed * 0 + 0 * 0) + (image2[i+1][j-1].rgbtRed * 1 + image2[i+1][j].rgbtRed * 2 + 0 * 1));
                tempGy = ((image2[i-1][j-1].rgbtGreen * -1 + image2[i-1][j].rgbtGreen * -2 + 0 * -1) + (image2[i][j-1].rgbtGreen * 0 + image2[i][j].rgbtGreen * 0 + 0 * 0) + (image2[i+1][j-1].rgbtGreen * 1 + image2[i+1][j].rgbtGreen * 2 + 0 * 1));
            }
            else // all middle pixels

            //if ((i > 0) && (i < height) && (j > 0) && ( j < width ))
            {
                tempBx = ((image2[i-1][j-1].rgbtBlue * -1 + image2[i-1][j].rgbtBlue * 0 + image2[i-1][j+1].rgbtBlue * 1) + (image2[i][j-1].rgbtBlue * -2 + image2[i][j].rgbtBlue * 0 + image2[i][j+1].rgbtBlue * 2) + (image2[i+1][j-1].rgbtBlue * -1 + image2[i+1][j].rgbtBlue * 0 + image2[i+1][j+1].rgbtBlue * 1));
                tempRx = ((image2[i-1][j-1].rgbtRed * -1 + image2[i-1][j].rgbtRed * 0 + image2[i-1][j+1].rgbtRed * 1) + (image2[i][j-1].rgbtRed * -2 + image2[i][j].rgbtRed * 0 + image2[i][j+1].rgbtRed * 2) + (image2[i+1][j-1].rgbtRed * -1 + image2[i+1][j].rgbtRed * 0 + image2[i+1][j+1].rgbtRed * 1));
                tempGx = ((image2[i-1][j-1].rgbtGreen * -1 + image2[i-1][j].rgbtGreen * 0 + image2[i-1][j+1].rgbtGreen * 1) + (image2[i][j-1].rgbtGreen * -2 + image2[i][j].rgbtGreen * 0 + image2[i][j+1].rgbtGreen * 2) + (image2[i+1][j-1].rgbtGreen * -1 + image2[i+1][j].rgbtGreen * 0 + image2[i+1][j+1].rgbtGreen * 1));

                tempBy = ((image2[i-1][j-1].rgbtBlue * -1 + image2[i-1][j].rgbtBlue * -2 + image2[i-1][j+1].rgbtBlue * -1) + (image2[i][j-1].rgbtBlue * 0 + image2[i][j].rgbtBlue * 0 + image2[i][j+1].rgbtBlue * 0) + (image2[i+1][j-1].rgbtBlue * 1 + image2[i+1][j].rgbtBlue * 2 + image2[i+1][j+1].rgbtBlue * 1));
                tempRy = ((image2[i-1][j-1].rgbtRed * -1 + image2[i-1][j].rgbtRed * -2 + image2[i-1][j+1].rgbtRed * -1) + (image2[i][j-1].rgbtRed * 0 + image2[i][j].rgbtRed * 0 + image2[i][j+1].rgbtRed * 0) + (image2[i+1][j-1].rgbtRed * 1 + image2[i+1][j].rgbtRed * 2 + image2[i+1][j+1].rgbtRed * 1));
                tempGy = ((image2[i-1][j-1].rgbtGreen * -1 + image2[i-1][j].rgbtGreen * -2 + image2[i-1][j+1].rgbtGreen * -1) + (image2[i][j-1].rgbtGreen * 0 + image2[i][j].rgbtGreen * 0 + image2[i][j+1].rgbtGreen * 0) + (image2[i+1][j-1].rgbtGreen * 1 + image2[i+1][j].rgbtGreen * 2 + image2[i+1][j+1].rgbtGreen * 1));
            }

            tempBxy = round(sqrt(pow(tempBx,2) + pow(tempBy,2)));
            tempRxy = round(sqrt(pow(tempRx,2) + pow(tempRy,2)));
            tempGxy = round(sqrt(pow(tempGx,2) + pow(tempGy,2)));

            image[i][j].rgbtBlue = limit(tempBxy);
            image[i][j].rgbtRed = limit(tempRxy);
            image[i][j].rgbtGreen = limit(tempGxy);
        }
    }
    return;
}

int limit(int input)
{
    if (input > 255)
    {
        return 255;
    }
    else return input;
}