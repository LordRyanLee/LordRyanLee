#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <getopt.h>
#include <stdbool.h>

typedef uint8_t BYTE;

int main(int argc, char *argv[])
{
    getopt(argc, argv, "");

    // Ensure proper usage
    if (argc != optind + 1)
    {
        printf("Usage: ./recover IMAGE\n");
        return 1;
    }

    // Open input file
    FILE *inptr = fopen(argv[1], "r");
    if (inptr == NULL)
    {
        printf("Could not open %s.\n", argv[1]);
        return 2;
    }

    // Read 512 BYTE each
    BYTE read_buffer[512];
    size_t read_bytes;
    char filename[20];
    int count = 0;
    FILE *outptr;
    bool found_JPG = false;

    do
    {
        read_bytes = fread(read_buffer, sizeof(BYTE), 512, inptr);
        if (read_bytes == 0)
        {
            // reach EOF
            fclose(inptr);
            fclose(outptr);
            //printf("\nEOF reach\n");
            return 0;
        }

        if (read_buffer[0] == 0xff && read_buffer[1] == 0xd8 && read_buffer[2] == 0xff && (read_buffer[3] & 0xf0) == 0xe0)
        {
            found_JPG = true;
            if (count > 0)
            {
                fclose(outptr);
            }
            sprintf(filename, "%03i.jpg", count);
            outptr = fopen(filename, "w");
            count++;
            //printf("count = %i\n",count);
            fwrite(read_buffer, sizeof(BYTE), 512, outptr);
        }
        else
        {
            if (found_JPG)
            {
                fwrite(read_buffer, sizeof(BYTE), 512, outptr);
            }
        }
    }
    while (read_bytes != 0);

    fclose(outptr);
    fclose(inptr);

    return 0;
}